# সমিতি ২.০

Kotlin + Jetpack Compose + Room ভিত্তিক starter Android project।

ফিচার:
- সদস্য নাম/ফোন/কিস্তি/তারিখ
- Room database-এ স্থায়ী সংরক্ষণ
- Paid/Unpaid
- সদস্য delete
- কিস্তির ৫ দিন আগে SMS alarm
- Android 12+ exact alarm fallback

Build:
Android Studio-তে folder খুলে Gradle Sync করুন, তারপর Build > Generate APKs।

Production release-এর আগে SMS policy, exact alarm permission, reboot rescheduling, backup/restore এবং আরও robust validation যোগ করা উচিত।
