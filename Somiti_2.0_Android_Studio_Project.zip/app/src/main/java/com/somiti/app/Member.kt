package com.somiti.app
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="members")
data class Member(
    @PrimaryKey(autoGenerate=true) val id: Long=0,
    val name: String,
    val phone: String,
    val amount: Double,
    val dueDate: Long,
    val frequency: String="মাসিক",
    val paid: Boolean=false
)
