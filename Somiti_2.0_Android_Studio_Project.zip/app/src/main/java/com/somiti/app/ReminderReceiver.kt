package com.somiti.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.*

class ReminderReceiver: BroadcastReceiver() {
    override fun onReceive(c:Context,i:Intent) {
        val phone=i.getStringExtra("phone") ?: return
        val name=i.getStringExtra("name") ?: ""
        val amount=i.getDoubleExtra("amount",0.0)
        val due=i.getLongExtra("dueDate",0)
        val d=SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date(due))
        val msg="প্রিয় $name, আপনার সমিতির কিস্তি ৳$amount পরিশোধের তারিখ $d। অনুগ্রহ করে সময়মতো কিস্তি পরিশোধ করুন। ধন্যবাদ।"
        try { SmsManager.getDefault().sendTextMessage(phone,null,msg,null,null) } catch(_:Exception){}
    }
}
