package com.somiti.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity: ComponentActivity() {
    private val sms = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) sms.launch(Manifest.permission.SEND_SMS)
        setContent { Somiti2App() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Somiti2App() {
    val dao=remember { SomitiDatabase.get().memberDao() }
    val members by dao.all().collectAsState(initial=emptyList())
    val scope=rememberCoroutineScope()
    var add by remember { mutableStateOf(false) }
    var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}
    var amount by remember{mutableStateOf("")}; var date by remember{mutableStateOf("")}

    MaterialTheme {
        Scaffold(topBar={TopAppBar(title={Text("সমিতি ২.০")})},
            floatingActionButton={FloatingActionButton(onClick={add=true}){Text("+")}}) { p ->
            Column(Modifier.padding(p).padding(16.dp)) {
                Text("মোট সদস্য: ${members.size}", style=MaterialTheme.typography.headlineSmall)
                Text("বকেয়া: ${members.count{!it.paid}} জন")
                Spacer(Modifier.height(10.dp))
                LazyColumn {
                    items(members,key={it.id}) { m ->
                        Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(m.name, style=MaterialTheme.typography.titleLarge)
                                Text("📞 ${m.phone}")
                                Text("💰 কিস্তি: ৳${m.amount}")
                                Text("📅 ${SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date(m.dueDate))}")
                                Text(if(m.paid) "✅ Paid" else "⏳ Unpaid")
                                Row {
                                    TextButton(onClick={scope.launch{dao.update(m.copy(paid=!m.paid))}}){Text(if(m.paid)"Unpaid করুন" else "Paid করুন")}
                                    TextButton(onClick={scope.launch{dao.delete(m)}}){Text("মুছুন")}
                                }
                                TextButton(onClick={scheduleSms(m)}){Text("৫ দিন আগে SMS সেট করুন")}
                            }
                        }
                    }
                }
            }
            if(add) AlertDialog(onDismissRequest={add=false},title={Text("নতুন সদস্য")},
                text={Column{
                    OutlinedTextField(name,{name=it},label={Text("সদস্যের নাম")})
                    OutlinedTextField(phone,{phone=it},label={Text("ফোন নম্বর")})
                    OutlinedTextField(amount,{amount=it},label={Text("কিস্তির পরিমাণ")})
                    OutlinedTextField(date,{date=it},label={Text("তারিখ DD-MM-YYYY")})
                }},
                confirmButton={TextButton(onClick={
                    try{
                        val d=SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).parse(date)!!.time
                        scope.launch{ val m=Member(name=name,phone=phone,amount=amount.toDouble(),dueDate=d); dao.insert(m); scheduleSms(m) }
                        name="";phone="";amount="";date="";add=false
                    }catch(_:Exception){}
                }){Text("সংরক্ষণ")}},
                dismissButton={TextButton(onClick={add=false}){Text("বাতিল")}})
        }
    }
}

fun scheduleSms(m:Member) {
    val trigger=m.dueDate-5L*24*60*60*1000
    val i=Intent(App.context,ReminderReceiver::class.java).apply{
        putExtra("phone",m.phone);putExtra("name",m.name);putExtra("amount",m.amount);putExtra("dueDate",m.dueDate)
    }
    val pi=PendingIntent.getBroadcast(App.context,m.id.toInt(),i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val am=App.context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    if(android.os.Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi)
    } else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi)
}
