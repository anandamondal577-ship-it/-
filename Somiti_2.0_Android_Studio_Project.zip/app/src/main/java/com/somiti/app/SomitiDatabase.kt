package com.somiti.app
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities=[Member::class], version=1, exportSchema=false)
abstract class SomitiDatabase: RoomDatabase() {
    abstract fun memberDao(): MemberDao
    companion object {
        @Volatile private var INSTANCE: SomitiDatabase?=null
        fun get(): SomitiDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(App.context, SomitiDatabase::class.java, "somiti.db").build().also { INSTANCE=it }
        }
    }
}
