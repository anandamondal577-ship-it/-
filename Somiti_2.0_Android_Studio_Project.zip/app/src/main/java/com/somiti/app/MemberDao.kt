package com.somiti.app
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MemberDao {
    @Query("SELECT * FROM members ORDER BY dueDate ASC")
    fun all(): Flow<List<Member>>
    @Insert suspend fun insert(m: Member)
    @Update suspend fun update(m: Member)
    @Delete suspend fun delete(m: Member)
}
