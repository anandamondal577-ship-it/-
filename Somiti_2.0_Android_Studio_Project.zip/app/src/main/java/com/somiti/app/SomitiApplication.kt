package com.somiti.app
import android.app.Application
class SomitiApplication: Application() {
    override fun onCreate() { super.onCreate(); App.context=this }
}
object App { lateinit var context: android.content.Context }
