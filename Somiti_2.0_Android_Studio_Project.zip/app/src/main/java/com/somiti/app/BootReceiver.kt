package com.somiti.app
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver: BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        // Future enhancement: reload database and reschedule all pending alarms.
    }
}
